<template>
<span class="dg-btn-loader">
	<span class="dg-circles">
		<span class="dg-circle"></span>
		<span class="dg-circle"></span>
		<span class="dg-circle"></span>
	</span>
</span>
</template>
